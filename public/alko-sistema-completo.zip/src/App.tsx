import React, { useState, useEffect, useCallback } from 'react';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { Dashboard } from './components/Dashboard';
import { KanbanBoard } from './components/KanbanBoard';
import { DemandList } from './components/DemandList';
import { QuickNotes } from './components/QuickNotes';
import { AuditLog } from './components/AuditLog';
import { TeamManagement } from './components/TeamManagement';
import { DemandModal } from './components/DemandModal';
import { LoginModal } from './components/LoginModal';
import { ToastContainer, ToastMessage } from './components/Toast';
import { StorageService } from './lib/storage';
import { 
  ActiveTab, 
  Demand, 
  QuickNote, 
  User, 
  DemandStatus 
} from './types';
import { 
  LayoutDashboard, 
  KanbanSquare, 
  ClipboardList, 
  StickyNote, 
  History, 
  Users 
} from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('dashboard');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  // Dados centrais
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [demands, setDemands] = useState<Demand[]>([]);
  const [notes, setNotes] = useState<QuickNote[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [auditLogs, setAuditLogs] = useState(StorageService.getAuditLogs());

  // Modais
  const [isDemandModalOpen, setIsDemandModalOpen] = useState(false);
  const [selectedDemand, setSelectedDemand] = useState<Demand | null>(null);
  const [defaultDemandStatus, setDefaultDemandStatus] = useState<DemandStatus>('A Fazer');
  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);

  // Toasts
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const addToast = useCallback((type: 'success' | 'error' | 'info', title: string, description?: string) => {
    const id = Math.random().toString(36).substring(2, 9);
    setToasts((prev) => [...prev, { id, type, title, description }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4000);
  }, []);

  const dismissToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  // Carregar dados iniciais
  useEffect(() => {
    const initialUser = StorageService.getCurrentUser();
    setCurrentUser(initialUser);
    setDemands(StorageService.getDemands());
    setNotes(StorageService.getNotes());
    setUsers(StorageService.getUsers());
    setAuditLogs(StorageService.getAuditLogs());
  }, []);

  // Handlers para Demandas
  const handleOpenNewDemand = (defaultStatus: DemandStatus = 'A Fazer') => {
    setSelectedDemand(null);
    setDefaultDemandStatus(defaultStatus);
    setIsDemandModalOpen(true);
  };

  const handleSelectDemand = (demand: Demand) => {
    setSelectedDemand(demand);
    setIsDemandModalOpen(true);
  };

  const handleSaveDemand = (data: Partial<Demand>) => {
    try {
      const saved = StorageService.saveDemand(data);
      setDemands(StorageService.getDemands());
      setAuditLogs(StorageService.getAuditLogs());
      addToast(
        'success',
        data.id ? 'Demanda Atualizada' : 'Nova Demanda Criada',
        `Chamado #${saved.code} registrado com sucesso!`
      );
    } catch (error) {
      console.error(error);
      addToast('error', 'Erro ao salvar demanda', 'Verifique os campos informados.');
    }
  };

  const handleUpdateDemandStatus = (demandId: string, newStatus: DemandStatus) => {
    const updated = StorageService.updateDemandStatus(demandId, newStatus);
    if (updated) {
      setDemands(StorageService.getDemands());
      setAuditLogs(StorageService.getAuditLogs());
      addToast(
        'info',
        `Status Atualizado (#${updated.code})`,
        `Movido para "${newStatus}".`
      );
    }
  };

  const handleDeleteDemand = (demandId: string) => {
    const ok = StorageService.deleteDemand(demandId);
    if (ok) {
      setDemands(StorageService.getDemands());
      setAuditLogs(StorageService.getAuditLogs());
      addToast('info', 'Demanda Excluída', 'O chamado foi removido do sistema.');
    }
  };

  const handleAddDemandComment = (demandId: string, text: string) => {
    if (!currentUser) {
      addToast('error', 'Não autenticado', 'Faça login para comentar.');
      return;
    }
    const updated = StorageService.addDemandComment(demandId, text, currentUser);
    if (updated) {
      setDemands(StorageService.getDemands());
      setSelectedDemand(updated);
      setAuditLogs(StorageService.getAuditLogs());
      addToast('success', 'Comentário Adicionado', 'Observação técnica registrada.');
    }
  };

  // Handlers para Notas
  const handleSaveNote = (noteData: Partial<QuickNote>) => {
    if (!currentUser) {
      addToast('error', 'Erro', 'Usuário não autenticado.');
      return;
    }
    StorageService.saveNote(noteData, currentUser);
    setNotes(StorageService.getNotes());
    setAuditLogs(StorageService.getAuditLogs());
    addToast('success', 'Nota Salva', 'Seu lembrete foi armazenado.');
  };

  const handleDeleteNote = (noteId: string) => {
    StorageService.deleteNote(noteId);
    setNotes(StorageService.getNotes());
    setAuditLogs(StorageService.getAuditLogs());
    addToast('info', 'Nota Excluída', 'Lembrete removido.');
  };

  const handleTogglePinNote = (noteId: string) => {
    StorageService.togglePinNote(noteId);
    setNotes(StorageService.getNotes());
  };

  // Handlers para Equipe & Usuários
  const handleSaveUser = (userData: Omit<User, 'id' | 'createdAt'> & { id?: string; password?: string }) => {
    try {
      StorageService.saveUser(userData);
      setUsers(StorageService.getUsers());
      setAuditLogs(StorageService.getAuditLogs());
      addToast('success', 'Usuário Atualizado', `Permissões para ${userData.name} configuradas.`);
    } catch (err: any) {
      addToast('error', 'Erro ao salvar usuário', err?.message || 'Falha ao salvar.');
    }
  };

  const handleDeleteUser = (userId: string) => {
    try {
      StorageService.deleteUser(userId);
      setUsers(StorageService.getUsers());
      setAuditLogs(StorageService.getAuditLogs());
      addToast('info', 'Usuário Removido', 'Acesso revogado.');
    } catch (err: any) {
      addToast('error', 'Erro', err?.message || 'Não foi possível excluir.');
    }
  };

  // Handlers de Autenticação
  const handleLogin = (email: string, pass: string): boolean => {
    const user = StorageService.authenticate(email, pass);
    if (user) {
      setCurrentUser(user);
      setAuditLogs(StorageService.getAuditLogs());
      addToast('success', `Bem-vindo, ${user.name}!`, `Conectado como ${user.role}.`);
      return true;
    }
    return false;
  };

  const handleLogout = () => {
    StorageService.setCurrentUser(null);
    setCurrentUser(null);
    addToast('info', 'Sessão Encerrada', 'Você saiu do sistema Alko TI.');
  };

  const handleSwitchToAdmin = () => {
    const ok = handleLogin('admin@alko.com.br', 'Alko@2026');
    if (ok) {
      setActiveTab('team');
    }
  };

  return (
    <div className="min-h-screen text-slate-900 flex flex-col font-sans relative overflow-x-hidden selection:bg-blue-600 selection:text-white">
      {/* Plano de Fundo Corporativo Farmacêutico com Suavização e Legibilidade WCAG */}
      <div 
        id="pharma-background-layer"
        className="fixed inset-0 pointer-events-none z-0 bg-cover bg-center bg-no-repeat"
        style={{ backgroundImage: `url('/pharma-bg.jpg')` }}
      >
        <div className="absolute inset-0 bg-slate-50/92 backdrop-blur-[1px]" />
      </div>

      <div className="relative z-10 flex flex-col min-h-screen">
        {/* Cabeçalho Principal */}
        <Header
          currentUser={currentUser}
          onOpenMobileMenu={() => setIsMobileMenuOpen(true)}
          onOpenNewDemandModal={() => handleOpenNewDemand()}
          onOpenLoginModal={() => setIsLoginModalOpen(true)}
          onLogout={handleLogout}
        />

        <div className="flex-1 flex max-w-7xl w-full mx-auto">
        {/* Barra Lateral de Navegação (Desktop & Mobile Drawer) */}
        <Sidebar
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          currentUser={currentUser}
          isOpenMobile={isMobileMenuOpen}
          onCloseMobile={() => setIsMobileMenuOpen(false)}
          demandsCount={demands.length}
          notesCount={notes.length}
          onResetData={() => {
            StorageService.resetToDefaultData();
            addToast('info', 'Dados Restaurados', 'Base de dados Alko TI redefinida.');
          }}
        />

        {/* Conteúdo Principal da Aba */}
        <main className="flex-1 p-4 sm:p-6 lg:p-8 min-w-0 overflow-x-hidden">
          {activeTab === 'dashboard' && (
            <Dashboard
              demands={demands}
              notes={notes}
              auditLogs={auditLogs}
              onOpenNewDemand={() => handleOpenNewDemand()}
              onNavigateToTab={(tab) => setActiveTab(tab)}
              onSelectDemand={handleSelectDemand}
            />
          )}

          {activeTab === 'kanban' && (
            <KanbanBoard
              demands={demands}
              onOpenNewDemand={handleOpenNewDemand}
              onSelectDemand={handleSelectDemand}
              onUpdateStatus={handleUpdateDemandStatus}
            />
          )}

          {activeTab === 'demands' && (
            <DemandList
              demands={demands}
              onOpenNewDemand={() => handleOpenNewDemand()}
              onSelectDemand={handleSelectDemand}
              onUpdateStatus={handleUpdateDemandStatus}
              onDeleteDemand={handleDeleteDemand}
            />
          )}

          {activeTab === 'notes' && (
            <QuickNotes
              notes={notes}
              currentUser={currentUser}
              onSaveNote={handleSaveNote}
              onDeleteNote={handleDeleteNote}
              onTogglePin={handleTogglePinNote}
            />
          )}

          {activeTab === 'audit' && (
            <AuditLog
              logs={auditLogs}
              onExportCsv={() => {
                StorageService.exportAuditLogsToCsv();
                addToast('success', 'Relatório CSV Gerado', 'Arquivo de auditoria baixado com sucesso!');
              }}
            />
          )}

          {activeTab === 'team' && (
            <TeamManagement
              users={users}
              currentUser={currentUser}
              onSaveUser={handleSaveUser}
              onDeleteUser={handleDeleteUser}
              onSwitchToAdmin={handleSwitchToAdmin}
            />
          )}
        </main>
      </div>

      {/* Barra de Navegação Inferior Móvel (Bottom Bar para Toque Fácil) */}
      <nav 
        id="mobile-bottom-nav"
        className="lg:hidden sticky bottom-0 z-30 bg-white/95 backdrop-blur-md border-t border-slate-200 px-2 py-1.5 flex items-center justify-around shadow-lg"
      >
        <button
          id="btn-bottom-dashboard"
          onClick={() => setActiveTab('dashboard')}
          className={`flex flex-col items-center justify-center min-h-[46px] min-w-[56px] px-2 py-1 rounded-xl transition-all active:scale-95 touch-manipulation ${
            activeTab === 'dashboard' ? 'text-blue-600 font-bold' : 'text-slate-500'
          }`}
        >
          <LayoutDashboard className="w-5 h-5" />
          <span className="text-[10px] mt-0.5">Visão</span>
        </button>

        <button
          id="btn-bottom-kanban"
          onClick={() => setActiveTab('kanban')}
          className={`flex flex-col items-center justify-center min-h-[46px] min-w-[56px] px-2 py-1 rounded-xl transition-all active:scale-95 touch-manipulation relative ${
            activeTab === 'kanban' ? 'text-blue-600 font-bold' : 'text-slate-500'
          }`}
        >
          <KanbanSquare className="w-5 h-5" />
          <span className="text-[10px] mt-0.5">Kanban</span>
          {demands.length > 0 && (
            <span className="absolute top-1 right-2 w-2 h-2 rounded-full bg-blue-600" />
          )}
        </button>

        <button
          id="btn-bottom-demands"
          onClick={() => setActiveTab('demands')}
          className={`flex flex-col items-center justify-center min-h-[46px] min-w-[56px] px-2 py-1 rounded-xl transition-all active:scale-95 touch-manipulation ${
            activeTab === 'demands' ? 'text-blue-600 font-bold' : 'text-slate-500'
          }`}
        >
          <ClipboardList className="w-5 h-5" />
          <span className="text-[10px] mt-0.5">Demandas</span>
        </button>

        <button
          id="btn-bottom-notes"
          onClick={() => setActiveTab('notes')}
          className={`flex flex-col items-center justify-center min-h-[46px] min-w-[56px] px-2 py-1 rounded-xl transition-all active:scale-95 touch-manipulation ${
            activeTab === 'notes' ? 'text-blue-600 font-bold' : 'text-slate-500'
          }`}
        >
          <StickyNote className="w-5 h-5" />
          <span className="text-[10px] mt-0.5">Notas</span>
        </button>

        <button
          id="btn-bottom-more"
          onClick={() => setIsMobileMenuOpen(true)}
          className="flex flex-col items-center justify-center min-h-[46px] min-w-[56px] px-2 py-1 rounded-xl text-slate-500 transition-all active:scale-95 touch-manipulation"
        >
          <Users className="w-5 h-5" />
          <span className="text-[10px] mt-0.5">Menu</span>
        </button>
      </nav>

      {/* Modal de Criação / Edição de Demanda */}
      <DemandModal
        isOpen={isDemandModalOpen}
        demand={selectedDemand}
        currentUser={currentUser}
        teamMembers={users}
        defaultStatus={defaultDemandStatus}
        onClose={() => setIsDemandModalOpen(false)}
        onSave={handleSaveDemand}
        onAddComment={handleAddDemandComment}
      />

      {/* Modal de Login */}
      <LoginModal
        isOpen={isLoginModalOpen}
        onClose={() => setIsLoginModalOpen(false)}
        onLogin={handleLogin}
        availableUsers={users}
      />

      {/* Container de Notificações Toast */}
      <ToastContainer toasts={toasts} onDismiss={dismissToast} />
      </div>
    </div>
  );
}
