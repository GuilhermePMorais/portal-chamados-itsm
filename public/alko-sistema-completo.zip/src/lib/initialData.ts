import { User, Demand, QuickNote, AuditLogItem } from '../types';

export const INITIAL_USERS: (User & { passwordHash?: string })[] = [
  {
    id: 'usr-admin',
    name: 'Administrador Alko',
    email: 'admin@alko.com.br',
    role: 'Administrador',
    department: 'TI & Governança',
    avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    active: true,
    createdAt: '2025-01-10T08:00:00Z',
    passwordHash: 'Alko@2026'
  },
  {
    id: 'usr-facilities',
    name: 'Roberto Mendes',
    email: 'roberto.mendes@alko.com.br',
    role: 'Supervisor de Facilities',
    department: 'Facilities & Infraestrutura',
    avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
    active: true,
    createdAt: '2025-01-15T09:30:00Z',
    passwordHash: 'Alko@123'
  },
  {
    id: 'usr-analyst',
    name: 'Mariana Souza',
    email: 'mariana.souza@alko.com.br',
    role: 'Analista',
    department: 'TI & Sistemas',
    avatarUrl: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80',
    active: true,
    createdAt: '2025-02-01T10:00:00Z',
    passwordHash: 'Alko@123'
  },
  {
    id: 'usr-technician',
    name: 'Carlos Andrade',
    email: 'carlos.andrade@alko.com.br',
    role: 'Técnico',
    department: 'Suporte Técnico',
    avatarUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
    active: true,
    createdAt: '2025-02-10T11:00:00Z',
    passwordHash: 'Alko@123'
  },
  {
    id: 'usr-assistant',
    name: 'Lucas Silva',
    email: 'lucas.silva@alko.com.br',
    role: 'Assistente',
    department: 'TI Operacional',
    avatarUrl: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=150&auto=format&fit=crop&q=80',
    active: true,
    createdAt: '2025-03-01T08:30:00Z',
    passwordHash: 'Alko@123'
  },
  {
    id: 'usr-auxiliary',
    name: 'Beatriz Costa',
    email: 'beatriz.costa@alko.com.br',
    role: 'Auxiliar',
    department: 'Helpdesk Nível 1',
    avatarUrl: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150&auto=format&fit=crop&q=80',
    active: true,
    createdAt: '2025-03-15T09:00:00Z',
    passwordHash: 'Alko@123'
  }
];

export const INITIAL_DEMANDS: Demand[] = [
  {
    id: 'dem-101',
    code: 'ALK-101',
    title: 'Falha de comunicação no coletor de dados - Linha Bobinamento 03',
    description: 'O coletor Zebra TC21 não consegue transmitir as leituras de código de barras para o ERP. Parada parcial de conferência de bobinas laminadas.',
    requester: 'Marcos Vinicius (Supervisor Produção)',
    requesterEmail: 'marcos.vinicius@alko.com.br',
    department: 'Produção & Fábrica',
    category: 'Hardware',
    priority: 'Crítica',
    status: 'Em Andamento',
    assignedTo: 'Carlos Andrade',
    dueDate: '2026-09-11',
    createdAt: '2026-09-09T08:15:00Z',
    updatedAt: '2026-09-10T10:30:00Z',
    resolutionTimeHours: 4,
    tags: ['Coletor', 'Fábrica', 'Urgente'],
    comments: [
      {
        id: 'comm-1',
        authorName: 'Carlos Andrade',
        authorRole: 'Técnico',
        content: 'Verificado que o access point do galpão 2 reiniciou e perdeu a VLAN de coletores. Reconfigurando o switch.',
        createdAt: '2026-09-10T09:20:00Z'
      }
    ]
  },
  {
    id: 'dem-102',
    code: 'ALK-102',
    title: 'Configuração de VPN e certificado A1 para Supervisão Financeira',
    description: 'Instalação do cliente VPN FortiClient e emissão de permissão de acesso bancário no notebook Dell corporativo da supervisora.',
    requester: 'Clara Meirelles',
    requesterEmail: 'clara.meirelles@alko.com.br',
    department: 'Financeiro',
    category: 'Acessos & Contas',
    priority: 'Alta',
    status: 'Concluído',
    assignedTo: 'Mariana Souza',
    dueDate: '2026-09-09',
    createdAt: '2026-09-08T14:00:00Z',
    updatedAt: '2026-09-09T16:45:00Z',
    resolutionTimeHours: 2,
    tags: ['VPN', 'Segurança', 'Financeiro'],
    comments: [
      {
        id: 'comm-2',
        authorName: 'Mariana Souza',
        authorRole: 'Analista',
        content: 'VPN configurada, MFA no celular ativado e teste de emissão de NF-e realizado com sucesso.',
        createdAt: '2026-09-09T16:40:00Z'
      }
    ]
  },
  {
    id: 'dem-103',
    code: 'ALK-103',
    title: 'Troca de cabeça de impressão da impressora Zebra térmica de etiquetas',
    description: 'A impressora do almoxarifado de matérias-primas está saindo com falha vertical no código EAN-13, dificultando a leitura óptica.',
    requester: 'Danilo Pacheco',
    requesterEmail: 'danilo.pacheco@alko.com.br',
    department: 'Logística & Expedição',
    category: 'Impressoras',
    priority: 'Média',
    status: 'A Fazer',
    assignedTo: 'Lucas Silva',
    dueDate: '2026-09-12',
    createdAt: '2026-09-10T07:45:00Z',
    updatedAt: '2026-09-10T07:45:00Z',
    resolutionTimeHours: 6,
    tags: ['Impressora', 'Zebra', 'Almoxarifado'],
    comments: []
  },
  {
    id: 'dem-104',
    code: 'ALK-104',
    title: 'Cotação e compra de peças sobressalentes para servidores Dell PowerEdge',
    description: 'Aguardando aprovação do fornecedor credenciado para fornecimento de 2 discos SAS de 2.4TB 10K RPM para reposição do storage.',
    requester: 'Mariana Souza',
    requesterEmail: 'mariana.souza@alko.com.br',
    department: 'TI & Governança',
    category: 'Hardware',
    priority: 'Alta',
    status: 'Aguardando Fornecedor',
    assignedTo: 'Mariana Souza',
    dueDate: '2026-09-15',
    createdAt: '2026-09-07T11:00:00Z',
    updatedAt: '2026-09-09T13:10:00Z',
    resolutionTimeHours: 48,
    tags: ['Servidores', 'Storage', 'Fornecedor'],
    comments: [
      {
        id: 'comm-3',
        authorName: 'Mariana Souza',
        authorRole: 'Analista',
        content: 'Orçamento número 4491 enviado para assinatura da diretoria.',
        createdAt: '2026-09-09T13:10:00Z'
      }
    ]
  },
  {
    id: 'dem-105',
    code: 'ALK-105',
    title: 'Novo ponto de rede cabeada Cat6 para balança de pesagem rodoviária',
    description: 'Passagem de cabeamento estruturado e instalação de conector fêmea blindado no painel da portaria principal.',
    requester: 'Roberto Mendes',
    requesterEmail: 'roberto.mendes@alko.com.br',
    department: 'Facilities & Infraestrutura',
    category: 'Facilities & Infra',
    priority: 'Média',
    status: 'Em Testes',
    assignedTo: 'Carlos Andrade',
    dueDate: '2026-09-11',
    createdAt: '2026-09-08T09:30:00Z',
    updatedAt: '2026-09-10T11:15:00Z',
    resolutionTimeHours: 8,
    tags: ['Infra', 'Rede', 'Balança'],
    comments: [
      {
        id: 'comm-4',
        authorName: 'Carlos Andrade',
        authorRole: 'Técnico',
        content: 'Cabo passado e conector testado com Fluke. Aguardando a transportadora ligar o visor digital para teste fim a fim.',
        createdAt: '2026-09-10T11:15:00Z'
      }
    ]
  },
  {
    id: 'dem-106',
    code: 'ALK-106',
    title: 'Lentidão intermitente no módulo de faturamento do ERP',
    description: 'Usuários do faturamento relatam travamentos ao emitir notas fiscais em lote nos horários de pico (11h às 12h e 16h às 17h).',
    requester: 'Eduardo Silveira (Gerente Vendas)',
    requesterEmail: 'eduardo.silveira@alko.com.br',
    department: 'Comercial & Vendas',
    category: 'ERP / SAP',
    priority: 'Crítica',
    status: 'Em Andamento',
    assignedTo: 'Mariana Souza',
    dueDate: '2026-09-10',
    createdAt: '2026-09-09T16:00:00Z',
    updatedAt: '2026-09-10T08:50:00Z',
    resolutionTimeHours: 5,
    tags: ['ERP', 'Banco de Dados', 'Faturamento'],
    comments: [
      {
        id: 'comm-5',
        authorName: 'Mariana Souza',
        authorRole: 'Analista',
        content: 'Detectado lock de tabelas de estoque devido a relatório concorrente. Criado índice no banco para otimização da consulta.',
        createdAt: '2026-09-10T08:50:00Z'
      }
    ]
  },
  {
    id: 'dem-107',
    code: 'ALK-107',
    title: 'Substituição e teste das baterias do Nobreak 10kVA - Datacenter',
    description: 'Manutenção preventiva preventiva semestral recomendada pelo fabricante APC. Banco de baterias seladas 12V.',
    requester: 'Roberto Mendes',
    requesterEmail: 'roberto.mendes@alko.com.br',
    department: 'Facilities & Infraestrutura',
    category: 'Facilities & Infra',
    priority: 'Alta',
    status: 'A Fazer',
    assignedTo: 'Carlos Andrade',
    dueDate: '2026-09-14',
    createdAt: '2026-09-10T09:00:00Z',
    updatedAt: '2026-09-10T09:00:00Z',
    resolutionTimeHours: 12,
    tags: ['Nobreak', 'Datacenter', 'Preventiva'],
    comments: []
  },
  {
    id: 'dem-108',
    code: 'ALK-108',
    title: 'Criação de usuário e e-mail corporativo para novo Operador Químico',
    description: 'Criação de conta Active Directory, e-mail @alko.com.br e permissão de leitura nos procedimentos operacionais (POPs).',
    requester: 'Juliana Fagundes (RH)',
    requesterEmail: 'juliana.fagundes@alko.com.br',
    department: 'Recursos Humanos',
    category: 'Acessos & Contas',
    priority: 'Baixa',
    status: 'Concluído',
    assignedTo: 'Beatriz Costa',
    dueDate: '2026-09-09',
    createdAt: '2026-09-08T10:15:00Z',
    updatedAt: '2026-09-08T15:20:00Z',
    resolutionTimeHours: 1,
    tags: ['Admissão', 'Active Directory', 'RH'],
    comments: []
  }
];

export const INITIAL_NOTES: QuickNote[] = [
  {
    id: 'note-1',
    title: 'Backup Semanal dos Servidores',
    content: 'Rotina de backup full agendada para sexta-feira às 22:00. Verificar fitas LTO e espaço livre no storage NAS.',
    color: 'yellow',
    pinned: true,
    authorId: 'usr-admin',
    authorName: 'Administrador Alko',
    createdAt: '2026-09-08T10:00:00Z',
    updatedAt: '2026-09-08T10:00:00Z'
  },
  {
    id: 'note-2',
    title: 'Janela de Manutenção Fibra Óptica',
    content: 'A operadora de telecom fará troca de fusão no sábado das 07h às 10h. O link redundante 4G/Rádio assumirá automaticamente.',
    color: 'blue',
    pinned: true,
    authorId: 'usr-analyst',
    authorName: 'Mariana Souza',
    createdAt: '2026-09-09T14:30:00Z',
    updatedAt: '2026-09-09T14:30:00Z'
  },
  {
    id: 'note-3',
    title: 'Inventário de Toners da Expedição',
    content: 'Comprar 4 unidades do toner HP 85A e 2 rolos térmicos 100x150mm para as impressoras de expedição da fábrica.',
    color: 'green',
    pinned: false,
    authorId: 'usr-technician',
    authorName: 'Carlos Andrade',
    createdAt: '2026-09-10T08:10:00Z',
    updatedAt: '2026-09-10T08:10:00Z'
  },
  {
    id: 'note-4',
    title: 'Ramais Telefônicos Alko',
    content: 'Diretoria: 201 | TI Suporte: 250 | Manutenção/Facilities: 310 | Almoxarifado: 405 | Portaria: 100',
    color: 'purple',
    pinned: false,
    authorId: 'usr-assistant',
    authorName: 'Lucas Silva',
    createdAt: '2026-09-05T09:00:00Z',
    updatedAt: '2026-09-05T09:00:00Z'
  }
];

export const INITIAL_AUDIT_LOGS: AuditLogItem[] = [
  {
    id: 'aud-1',
    action: 'Login',
    description: 'Usuário administrador autenticado com sucesso no sistema Alko IT',
    userEmail: 'admin@alko.com.br',
    userName: 'Administrador Alko',
    entityType: 'Autenticação',
    timestamp: '2026-09-10T08:00:12Z'
  },
  {
    id: 'aud-2',
    action: 'Criação',
    description: 'Criou chamado #ALK-107: "Substituição e teste das baterias do Nobreak 10kVA"',
    userEmail: 'roberto.mendes@alko.com.br',
    userName: 'Roberto Mendes',
    entityType: 'Demanda',
    entityId: 'dem-107',
    timestamp: '2026-09-10T09:00:30Z'
  },
  {
    id: 'aud-3',
    action: 'Status Alterado',
    description: 'Moveu chamado #ALK-101 para o status "Em Andamento"',
    userEmail: 'carlos.andrade@alko.com.br',
    userName: 'Carlos Andrade',
    entityType: 'Demanda',
    entityId: 'dem-101',
    timestamp: '2026-09-10T09:25:00Z'
  },
  {
    id: 'aud-4',
    action: 'Atualização',
    description: 'Adicionou nota de manutenção preventiva da fibra óptica',
    userEmail: 'mariana.souza@alko.com.br',
    userName: 'Mariana Souza',
    entityType: 'Nota',
    entityId: 'note-2',
    timestamp: '2026-09-09T14:30:00Z'
  },
  {
    id: 'aud-5',
    action: 'Status Alterado',
    description: 'Finalizou chamado #ALK-102 com status "Concluído" (SLA cumprido)',
    userEmail: 'mariana.souza@alko.com.br',
    userName: 'Mariana Souza',
    entityType: 'Demanda',
    entityId: 'dem-102',
    timestamp: '2026-09-09T16:45:10Z'
  }
];
