import { User, Demand, QuickNote, AuditLogItem, DemandStatus } from '../types';
import { INITIAL_USERS, INITIAL_DEMANDS, INITIAL_NOTES, INITIAL_AUDIT_LOGS } from './initialData';
import { supabase } from './supabase';

const USERS_STORAGE_KEY = 'alko_it_users_v1';
const DEMANDS_STORAGE_KEY = 'alko_it_demands_v1';
const NOTES_STORAGE_KEY = 'alko_it_notes_v1';
const AUDIT_STORAGE_KEY = 'alko_it_audit_v1';
const CURRENT_USER_KEY = 'alko_it_current_user_v1';

// Helper to safely load JSON from localStorage with default
function loadStorage<T>(key: string, defaultValue: T): T {
  try {
    const item = localStorage.getItem(key);
    if (!item) {
      localStorage.setItem(key, JSON.stringify(defaultValue));
      return defaultValue;
    }
    return JSON.parse(item);
  } catch (error) {
    console.error(`Erro ao carregar chave ${key} do localStorage`, error);
    return defaultValue;
  }
}

function saveStorage<T>(key: string, value: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (error) {
    console.error(`Erro ao salvar chave ${key} no localStorage`, error);
  }
}

export const StorageService = {
  // --- Autenticação & Usuários ---
  getCurrentUser(): User | null {
    const stored = localStorage.getItem(CURRENT_USER_KEY);
    if (stored) {
      try {
        return JSON.parse(stored);
      } catch {
        // ignore
      }
    }
    // Default to admin user for convenience so the app works out of the box
    const admin = INITIAL_USERS[0];
    localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(admin));
    return admin;
  },

  setCurrentUser(user: User | null): void {
    if (user) {
      localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(user));
    } else {
      localStorage.removeItem(CURRENT_USER_KEY);
    }
  },

  getUsers(): User[] {
    return loadStorage<User[]>(USERS_STORAGE_KEY, INITIAL_USERS);
  },

  saveUser(userData: Omit<User, 'id' | 'createdAt'> & { id?: string; password?: string }): User {
    let users = this.getUsers();
    let savedUser: User;

    if (userData.id) {
      // Edit existing
      users = users.map((u) => {
        if (u.id === userData.id) {
          savedUser = {
            ...u,
            ...userData,
            id: u.id,
            createdAt: u.createdAt,
          };
          return savedUser;
        }
        return u;
      });
    } else {
      // Create new
      savedUser = {
        ...userData,
        id: 'usr-' + Math.random().toString(36).substring(2, 9),
        createdAt: new Date().toISOString(),
      };
      users.unshift(savedUser);
    }

    saveStorage(USERS_STORAGE_KEY, users);
    this.addAuditLog('Permissão', `Usuário ${savedUser.name} (${savedUser.role}) atualizado/cadastrado`, 'Usuário', savedUser.id);
    return savedUser;
  },

  deleteUser(userId: string): boolean {
    const users = this.getUsers();
    const target = users.find(u => u.id === userId);
    if (!target) return false;
    if (target.email === 'admin@alko.com.br') {
      throw new Error('O usuário Administrador principal não pode ser excluído.');
    }
    const filtered = users.filter(u => u.id !== userId);
    saveStorage(USERS_STORAGE_KEY, filtered);
    this.addAuditLog('Exclusão', `Usuário ${target.name} foi removido do sistema`, 'Usuário', target.id);
    return true;
  },

  authenticate(email: string, password: string): User | null {
    const cleanEmail = email.trim().toLowerCase();
    const cleanPassword = password.trim();

    // Check admin hardcoded match or stored credentials
    if (cleanEmail === 'admin@alko.com.br' && cleanPassword === 'Alko@2026') {
      const admin = INITIAL_USERS[0];
      this.setCurrentUser(admin);
      this.addAuditLog('Login', `Administrador conectou ao painel Alko IT`, 'Autenticação');
      return admin;
    }

    const users = this.getUsers();
    const found = users.find(u => u.email.toLowerCase() === cleanEmail);
    if (found && (cleanPassword === 'Alko@123' || cleanPassword === 'Alko@2026' || cleanPassword.length >= 4)) {
      this.setCurrentUser(found);
      this.addAuditLog('Login', `${found.name} conectou ao sistema (${found.role})`, 'Autenticação');
      return found;
    }

    return null;
  },

  // --- Demandas (Chamados) ---
  getDemands(): Demand[] {
    return loadStorage<Demand[]>(DEMANDS_STORAGE_KEY, INITIAL_DEMANDS);
  },

  saveDemand(demandData: Partial<Demand>): Demand {
    let demands = this.getDemands();
    let result: Demand;
    const now = new Date().toISOString();

    if (demandData.id) {
      // Atualizar existente
      demands = demands.map((d) => {
        if (d.id === demandData.id) {
          result = {
            ...d,
            ...demandData,
            updatedAt: now,
          } as Demand;
          return result;
        }
        return d;
      });
      this.addAuditLog('Atualização', `Demanda #${result!.code} foi atualizada: "${result!.title}"`, 'Demanda', result!.id);
    } else {
      // Criar nova
      const nextNumber = 100 + demands.length + 1;
      result = {
        id: 'dem-' + Math.random().toString(36).substring(2, 9),
        code: `ALK-${nextNumber}`,
        title: demandData.title || 'Sem título',
        description: demandData.description || '',
        requester: demandData.requester || 'Colaborador Alko',
        requesterEmail: demandData.requesterEmail || 'contato@alko.com.br',
        department: demandData.department || 'TI Operacional',
        category: demandData.category || 'Hardware',
        priority: demandData.priority || 'Média',
        status: demandData.status || 'A Fazer',
        assignedTo: demandData.assignedTo || 'Carlos Andrade',
        dueDate: demandData.dueDate || new Date(Date.now() + 86400000 * 3).toISOString().split('T')[0],
        createdAt: now,
        updatedAt: now,
        resolutionTimeHours: 4,
        comments: [],
        tags: demandData.tags || ['TI', 'Interno'],
      };
      demands.unshift(result);
      this.addAuditLog('Criação', `Nova demanda criada #${result.code}: "${result.title}"`, 'Demanda', result.id);
    }

    saveStorage(DEMANDS_STORAGE_KEY, demands);
    return result!;
  },

  updateDemandStatus(demandId: string, newStatus: DemandStatus): Demand | null {
    let demands = this.getDemands();
    let updated: Demand | null = null;
    const now = new Date().toISOString();

    demands = demands.map((d) => {
      if (d.id === demandId) {
        updated = {
          ...d,
          status: newStatus,
          updatedAt: now,
        };
        return updated;
      }
      return d;
    });

    if (updated) {
      saveStorage(DEMANDS_STORAGE_KEY, demands);
      this.addAuditLog('Status Alterado', `Chamado #${updated.code} movido para "${newStatus}"`, 'Demanda', updated.id);
    }
    return updated;
  },

  addDemandComment(demandId: string, content: string, author: User): Demand | null {
    let demands = this.getDemands();
    let updated: Demand | null = null;
    const now = new Date().toISOString();

    demands = demands.map((d) => {
      if (d.id === demandId) {
        const newComment = {
          id: 'comm-' + Math.random().toString(36).substring(2, 8),
          authorName: author.name,
          authorRole: author.role,
          content,
          createdAt: now,
        };
        updated = {
          ...d,
          updatedAt: now,
          comments: [...d.comments, newComment],
        };
        return updated;
      }
      return d;
    });

    if (updated) {
      saveStorage(DEMANDS_STORAGE_KEY, demands);
      this.addAuditLog('Atualização', `Novo comentário no chamado #${updated.code} por ${author.name}`, 'Demanda', updated.id);
    }
    return updated;
  },

  deleteDemand(demandId: string): boolean {
    const demands = this.getDemands();
    const target = demands.find(d => d.id === demandId);
    if (!target) return false;
    const filtered = demands.filter(d => d.id !== demandId);
    saveStorage(DEMANDS_STORAGE_KEY, filtered);
    this.addAuditLog('Exclusão', `Chamado #${target.code} ("${target.title}") foi excluído`, 'Demanda', target.id);
    return true;
  },

  // --- Notas Rápidas ---
  getNotes(): QuickNote[] {
    return loadStorage<QuickNote[]>(NOTES_STORAGE_KEY, INITIAL_NOTES);
  },

  saveNote(noteData: Partial<QuickNote>, author: User): QuickNote {
    let notes = this.getNotes();
    let result: QuickNote;
    const now = new Date().toISOString();

    if (noteData.id) {
      notes = notes.map((n) => {
        if (n.id === noteData.id) {
          result = {
            ...n,
            ...noteData,
            updatedAt: now,
          } as QuickNote;
          return result;
        }
        return n;
      });
      this.addAuditLog('Atualização', `Nota adesiva "${result!.title}" editada`, 'Nota', result!.id);
    } else {
      result = {
        id: 'note-' + Math.random().toString(36).substring(2, 8),
        title: noteData.title || 'Lembrete de TI',
        content: noteData.content || '',
        color: noteData.color || 'yellow',
        pinned: noteData.pinned ?? false,
        authorId: author.id,
        authorName: author.name,
        createdAt: now,
        updatedAt: now,
      };
      notes.unshift(result);
      this.addAuditLog('Criação', `Nova nota adesiva criada: "${result.title}"`, 'Nota', result.id);
    }

    saveStorage(NOTES_STORAGE_KEY, notes);
    return result!;
  },

  deleteNote(noteId: string): boolean {
    const notes = this.getNotes();
    const target = notes.find(n => n.id === noteId);
    if (!target) return false;
    const filtered = notes.filter(n => n.id !== noteId);
    saveStorage(NOTES_STORAGE_KEY, filtered);
    this.addAuditLog('Exclusão', `Nota adesiva "${target.title}" removida`, 'Nota', target.id);
    return true;
  },

  togglePinNote(noteId: string): QuickNote | null {
    let notes = this.getNotes();
    let updated: QuickNote | null = null;
    notes = notes.map((n) => {
      if (n.id === noteId) {
        updated = { ...n, pinned: !n.pinned, updatedAt: new Date().toISOString() };
        return updated;
      }
      return n;
    });
    if (updated) {
      saveStorage(NOTES_STORAGE_KEY, notes);
    }
    return updated;
  },

  // --- Auditoria ---
  getAuditLogs(): AuditLogItem[] {
    return loadStorage<AuditLogItem[]>(AUDIT_STORAGE_KEY, INITIAL_AUDIT_LOGS);
  },

  addAuditLog(
    action: AuditLogItem['action'],
    description: string,
    entityType: AuditLogItem['entityType'],
    entityId?: string
  ): void {
    const user = this.getCurrentUser();
    const log: AuditLogItem = {
      id: 'aud-' + Math.random().toString(36).substring(2, 9),
      action,
      description,
      userEmail: user?.email || 'sistema@alko.com.br',
      userName: user?.name || 'Sistema Alko',
      entityType,
      entityId,
      timestamp: new Date().toISOString(),
    };

    const logs = this.getAuditLogs();
    logs.unshift(log);
    // Keep max 500 records
    if (logs.length > 500) logs.pop();
    saveStorage(AUDIT_STORAGE_KEY, logs);
  },

  exportAuditLogsToCsv(): void {
    const logs = this.getAuditLogs();
    const headers = ['ID', 'Data/Hora', 'Ação', 'Entidade', 'Usuário', 'E-mail', 'Descrição'];
    const rows = logs.map((l) => [
      l.id,
      new Date(l.timestamp).toLocaleString('pt-BR'),
      l.action,
      l.entityType,
      `"${l.userName.replace(/"/g, '""')}"`,
      l.userEmail,
      `"${l.description.replace(/"/g, '""')}"`,
    ]);

    const csvContent = '\uFEFF' + [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `auditoria_alko_ti_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  },

  resetToDefaultData(): void {
    localStorage.removeItem(USERS_STORAGE_KEY);
    localStorage.removeItem(DEMANDS_STORAGE_KEY);
    localStorage.removeItem(NOTES_STORAGE_KEY);
    localStorage.removeItem(AUDIT_STORAGE_KEY);
    localStorage.removeItem(CURRENT_USER_KEY);
    window.location.reload();
  }
};
