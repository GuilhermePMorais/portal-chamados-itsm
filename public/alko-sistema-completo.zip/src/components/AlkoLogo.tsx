import React from 'react';

interface AlkoLogoProps {
  className?: string;
  variant?: 'full' | 'icon';
  size?: 'sm' | 'md' | 'lg';
  theme?: 'dark' | 'light';
}

export const AlkoLogo: React.FC<AlkoLogoProps> = ({
  className = '',
  variant = 'full',
  size = 'md',
  theme = 'dark',
}) => {
  // Configurações de dimensão sutil e equilibrada
  const heightMap = {
    sm: 'h-7',
    md: 'h-9',
    lg: 'h-11',
  };

  const textColor = theme === 'light' ? '#ffffff' : '#0f172a';
  const subtextColor = theme === 'light' ? '#cbd5e1' : '#334155';

  if (variant === 'icon') {
    return (
      <svg
        viewBox="0 0 240 240"
        className={`${heightMap[size]} w-auto aspect-square select-none ${className}`}
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        aria-label="Logo Alko do Brasil"
      >
        <defs>
          <clipPath id="alko-icon-circle">
            <circle cx="120" cy="120" r="110" />
          </clipPath>
        </defs>
        <g clipPath="url(#alko-icon-circle)">
          {/* Círculo Azul Institucional Alko */}
          <rect width="240" height="240" fill="#00588e" />

          {/* Fendas/Nervuras simétricas em chevron branco */}
          <line x1="120" y1="0" x2="120" y2="240" stroke="#ffffff" strokeWidth="8" strokeLinecap="round" />
          
          <line x1="6" y1="56" x2="116" y2="92" stroke="#ffffff" strokeWidth="8.5" strokeLinecap="round" />
          <line x1="234" y1="56" x2="124" y2="92" stroke="#ffffff" strokeWidth="8.5" strokeLinecap="round" />
          
          <line x1="6" y1="108" x2="116" y2="144" stroke="#ffffff" strokeWidth="8.5" strokeLinecap="round" />
          <line x1="234" y1="108" x2="124" y2="144" stroke="#ffffff" strokeWidth="8.5" strokeLinecap="round" />
          
          <line x1="16" y1="162" x2="116" y2="198" stroke="#ffffff" strokeWidth="8.5" strokeLinecap="round" />
          <line x1="224" y1="162" x2="124" y2="198" stroke="#ffffff" strokeWidth="8.5" strokeLinecap="round" />

          <line x1="45" y1="214" x2="116" y2="240" stroke="#ffffff" strokeWidth="8.5" strokeLinecap="round" />
          <line x1="195" y1="214" x2="124" y2="240" stroke="#ffffff" strokeWidth="8.5" strokeLinecap="round" />
        </g>
      </svg>
    );
  }

  return (
    <svg
      viewBox="0 0 760 250"
      className={`${heightMap[size]} w-auto select-none ${className}`}
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      aria-label="Logo Alko do Brasil"
    >
      <defs>
        <clipPath id="alko-full-circle">
          <circle cx="120" cy="120" r="110" />
        </clipPath>
      </defs>

      {/* Símbolo do Globo Foliar Azul Alko */}
      <g transform="translate(10, 5)">
        <g clipPath="url(#alko-full-circle)">
          <rect width="240" height="240" fill="#00588e" />
          <line x1="120" y1="0" x2="120" y2="240" stroke="#ffffff" strokeWidth="8" strokeLinecap="round" />
          
          <line x1="6" y1="56" x2="116" y2="92" stroke="#ffffff" strokeWidth="8.5" strokeLinecap="round" />
          <line x1="234" y1="56" x2="124" y2="92" stroke="#ffffff" strokeWidth="8.5" strokeLinecap="round" />
          
          <line x1="6" y1="108" x2="116" y2="144" stroke="#ffffff" strokeWidth="8.5" strokeLinecap="round" />
          <line x1="234" y1="108" x2="124" y2="144" stroke="#ffffff" strokeWidth="8.5" strokeLinecap="round" />
          
          <line x1="16" y1="162" x2="116" y2="198" stroke="#ffffff" strokeWidth="8.5" strokeLinecap="round" />
          <line x1="224" y1="162" x2="124" y2="198" stroke="#ffffff" strokeWidth="8.5" strokeLinecap="round" />

          <line x1="45" y1="214" x2="116" y2="240" stroke="#ffffff" strokeWidth="8.5" strokeLinecap="round" />
          <line x1="195" y1="214" x2="124" y2="240" stroke="#ffffff" strokeWidth="8.5" strokeLinecap="round" />
        </g>
      </g>

      {/* Tipografia ALKO */}
      <g transform="translate(290, 138)" fill={textColor}>
        {/* Letra A com corte triangular modernista */}
        <path d="M 0,0 L 44,-108 L 86,-108 L 130,0 L 98,0 L 86,-30 L 44,-30 L 32,0 Z M 52,-54 L 78,-54 L 65,-87 Z" />
        {/* Letra L */}
        <path d="M 154,-108 L 184,-108 L 184,-26 L 244,-26 L 244,0 L 154,0 Z" />
        {/* Letra K */}
        <path d="M 270,-108 L 300,-108 L 300,-48 L 348,-108 L 388,-108 L 334,-42 L 392,0 L 352,0 L 300,-36 L 300,0 L 270,0 Z" />
        {/* Letra O */}
        <path d="M 454,-112 C 490,-112 516,-86 516,-54 C 516,-22 490,4 454,4 C 418,4 392,-22 392,-54 C 392,-86 418,-112 454,-112 Z M 454,-86 C 435,-86 422,-72 422,-54 C 422,-36 435,-22 454,-22 C 473,-22 486,-36 486,-54 C 486,-72 473,-86 454,-86 Z" />
      </g>

      {/* Subtítulo DO BRASIL em tracking alinhado */}
      <text
        x="292"
        y="186"
        fontFamily="system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif"
        fontSize="33"
        fontWeight="700"
        letterSpacing="0.46em"
        fill={subtextColor}
      >
        DO BRASIL
      </text>
    </svg>
  );
};
