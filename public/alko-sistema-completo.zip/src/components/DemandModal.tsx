import React, { useState, useEffect } from 'react';
import { 
  X, 
  Save, 
  Send, 
  User as UserIcon, 
  Calendar, 
  Tag, 
  Building2, 
  MessageSquare, 
  FileText,
  Clock,
  ShieldAlert
} from 'lucide-react';
import { 
  Demand, 
  DemandStatus, 
  DemandPriority, 
  DemandCategory, 
  User 
} from '../types';

interface DemandModalProps {
  isOpen: boolean;
  demand: Demand | null;
  currentUser: User | null;
  teamMembers: User[];
  defaultStatus?: DemandStatus;
  onClose: () => void;
  onSave: (data: Partial<Demand>) => void;
  onAddComment: (demandId: string, text: string) => void;
}

export const DemandModal: React.FC<DemandModalProps> = ({
  isOpen,
  demand,
  currentUser,
  teamMembers,
  defaultStatus = 'A Fazer',
  onClose,
  onSave,
  onAddComment,
}) => {
  const isEditing = Boolean(demand);

  const [activeTab, setActiveTab] = useState<'info' | 'comments'>('info');

  // Form states
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [requester, setRequester] = useState('');
  const [requesterEmail, setRequesterEmail] = useState('');
  const [department, setDepartment] = useState('Produção & Fábrica');
  const [category, setCategory] = useState<DemandCategory>('Hardware');
  const [priority, setPriority] = useState<DemandPriority>('Média');
  const [status, setStatus] = useState<DemandStatus>(defaultStatus);
  const [assignedTo, setAssignedTo] = useState('Carlos Andrade');
  const [dueDate, setDueDate] = useState('');
  const [commentText, setCommentText] = useState('');

  useEffect(() => {
    if (demand) {
      setTitle(demand.title);
      setDescription(demand.description);
      setRequester(demand.requester);
      setRequesterEmail(demand.requesterEmail);
      setDepartment(demand.department);
      setCategory(demand.category);
      setPriority(demand.priority);
      setStatus(demand.status);
      setAssignedTo(demand.assignedTo || '');
      setDueDate(demand.dueDate);
    } else {
      setTitle('');
      setDescription('');
      setRequester(currentUser?.name || '');
      setRequesterEmail(currentUser?.email || '');
      setDepartment('Produção & Fábrica');
      setCategory('Hardware');
      setPriority('Média');
      setStatus(defaultStatus);
      setAssignedTo(teamMembers[3]?.name || 'Carlos Andrade');
      // Default due date: in 3 days
      const d = new Date();
      d.setDate(d.getDate() + 3);
      setDueDate(d.toISOString().split('T')[0]);
    }
  }, [demand, isOpen, defaultStatus, currentUser, teamMembers]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) {
      alert('Por favor, informe o título da demanda.');
      return;
    }

    onSave({
      id: demand?.id,
      title: title.trim(),
      description: description.trim(),
      requester: requester.trim() || 'Colaborador Alko',
      requesterEmail: requesterEmail.trim() || 'suporte@alko.com.br',
      department,
      category,
      priority,
      status,
      assignedTo: assignedTo || undefined,
      dueDate,
    });
    onClose();
  };

  const handleSendComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!commentText.trim() || !demand) return;
    onAddComment(demand.id, commentText.trim());
    setCommentText('');
  };

  return (
    <div 
      id="demand-modal-overlay"
      className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 overflow-y-auto"
      onClick={onClose}
    >
      <div
        id="demand-modal-card"
        onClick={(e) => e.stopPropagation()}
        className="bg-white w-full max-w-2xl rounded-2xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh] my-auto animate-in fade-in zoom-in-95 duration-200"
      >
        {/* Topo do Modal */}
        <div className="p-4 sm:p-5 border-b border-slate-200 flex items-center justify-between bg-slate-50/70">
          <div>
            <div className="flex items-center gap-2">
              <span className="font-mono text-xs font-black px-2 py-0.5 rounded bg-blue-900 text-white">
                {demand ? demand.code : 'NOVA'}
              </span>
              <h2 className="text-base sm:text-lg font-bold text-slate-900">
                {isEditing ? 'Detalhes da Demanda' : 'Nova Demanda de TI'}
              </h2>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              Alko do Brasil • Registro de chamado e assistência técnica
            </p>
          </div>

          <button
            id="btn-close-demand-modal"
            onClick={onClose}
            aria-label="Fechar janela"
            className="w-10 h-10 flex items-center justify-center rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-200 active:bg-slate-300 transition-colors active:scale-95 touch-manipulation"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Abas do Modal (quando editando) */}
        {isEditing && (
          <div className="flex border-b border-slate-200 bg-white px-5">
            <button
              onClick={() => setActiveTab('info')}
              className={`min-h-[44px] px-4 text-xs font-bold border-b-2 flex items-center gap-2 transition-colors touch-manipulation ${
                activeTab === 'info'
                  ? 'border-blue-600 text-blue-600'
                  : 'border-transparent text-slate-500 hover:text-slate-800'
              }`}
            >
              <FileText className="w-4 h-4" />
              Informações do Chamado
            </button>

            <button
              onClick={() => setActiveTab('comments')}
              className={`min-h-[44px] px-4 text-xs font-bold border-b-2 flex items-center gap-2 transition-colors touch-manipulation ${
                activeTab === 'comments'
                  ? 'border-blue-600 text-blue-600'
                  : 'border-transparent text-slate-500 hover:text-slate-800'
              }`}
            >
              <MessageSquare className="w-4 h-4" />
              Histórico & Comentários ({demand?.comments.length || 0})
            </button>
          </div>
        )}

        {/* Corpo do Modal */}
        <div className="p-4 sm:p-6 overflow-y-auto flex-1 space-y-4">
          {activeTab === 'info' ? (
            <form id="form-demand" onSubmit={handleSubmit} className="space-y-4">
              {/* Título */}
              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  Título da Demanda *
                </label>
                <input
                  type="text"
                  id="input-demand-title"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="Ex: Falha na impressora de etiquetas da expedição"
                  className="w-full min-h-[44px] px-3.5 rounded-xl border border-slate-300 text-sm focus:ring-2 focus:ring-blue-500 focus:outline-none"
                />
              </div>

              {/* Grid: Categoria, Prioridade, Status */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">
                    Categoria
                  </label>
                  <select
                    id="input-demand-category"
                    value={category}
                    onChange={(e) => setCategory(e.target.value as DemandCategory)}
                    className="w-full min-h-[44px] px-3 rounded-xl border border-slate-300 text-xs font-medium focus:ring-2 focus:ring-blue-500 bg-white"
                  >
                    <option value="Hardware">Hardware</option>
                    <option value="Software">Software</option>
                    <option value="Redes & Internet">Redes & Internet</option>
                    <option value="Acessos & Contas">Acessos & Contas</option>
                    <option value="Impressoras">Impressoras</option>
                    <option value="Telefonia">Telefonia</option>
                    <option value="ERP / SAP">ERP / SAP</option>
                    <option value="Facilities & Infra">Facilities & Infra</option>
                  </select>
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">
                    Prioridade
                  </label>
                  <select
                    id="input-demand-priority"
                    value={priority}
                    onChange={(e) => setPriority(e.target.value as DemandPriority)}
                    className="w-full min-h-[44px] px-3 rounded-xl border border-slate-300 text-xs font-medium focus:ring-2 focus:ring-blue-500 bg-white"
                  >
                    <option value="Baixa">Baixa</option>
                    <option value="Média">Média</option>
                    <option value="Alta">Alta</option>
                    <option value="Crítica">Crítica</option>
                  </select>
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">
                    Status
                  </label>
                  <select
                    id="input-demand-status"
                    value={status}
                    onChange={(e) => setStatus(e.target.value as DemandStatus)}
                    className="w-full min-h-[44px] px-3 rounded-xl border border-slate-300 text-xs font-bold text-blue-900 focus:ring-2 focus:ring-blue-500 bg-white"
                  >
                    <option value="A Fazer">A Fazer</option>
                    <option value="Em Andamento">Em Andamento</option>
                    <option value="Aguardando Fornecedor">Aguardando Fornecedor</option>
                    <option value="Em Testes">Em Testes</option>
                    <option value="Concluído">Concluído</option>
                  </select>
                </div>
              </div>

              {/* Descrição */}
              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  Descrição do Problema / Solicitação
                </label>
                <textarea
                  id="input-demand-description"
                  rows={3}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Detalhe o erro, equipamento ou necessidade do colaborador..."
                  className="w-full p-3 rounded-xl border border-slate-300 text-xs leading-relaxed focus:ring-2 focus:ring-blue-500 focus:outline-none"
                />
              </div>

              {/* Grid: Solicitante e Departamento */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">
                    Solicitante
                  </label>
                  <input
                    type="text"
                    id="input-demand-requester"
                    value={requester}
                    onChange={(e) => setRequester(e.target.value)}
                    placeholder="Nome do colaborador"
                    className="w-full min-h-[44px] px-3.5 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-blue-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">
                    Departamento / Setor
                  </label>
                  <select
                    id="input-demand-department"
                    value={department}
                    onChange={(e) => setDepartment(e.target.value)}
                    className="w-full min-h-[44px] px-3 rounded-xl border border-slate-300 text-xs font-medium focus:ring-2 focus:ring-blue-500 bg-white"
                  >
                    <option value="Produção & Fábrica">Produção & Fábrica</option>
                    <option value="Logística & Expedição">Logística & Expedição</option>
                    <option value="Facilities & Infraestrutura">Facilities & Infraestrutura</option>
                    <option value="TI & Governança">TI & Governança</option>
                    <option value="Financeiro">Financeiro</option>
                    <option value="Recursos Humanos">Recursos Humanos</option>
                    <option value="Comercial & Vendas">Comercial & Vendas</option>
                    <option value="Qualidade & Laboratório">Qualidade & Laboratório</option>
                    <option value="Diretoria">Diretoria</option>
                  </select>
                </div>
              </div>

              {/* Grid: Técnico Responsável e Prazo */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">
                    Técnico Responsável
                  </label>
                  <select
                    id="input-demand-assigned"
                    value={assignedTo}
                    onChange={(e) => setAssignedTo(e.target.value)}
                    className="w-full min-h-[44px] px-3 rounded-xl border border-slate-300 text-xs font-medium focus:ring-2 focus:ring-blue-500 bg-white"
                  >
                    <option value="">Não atribuído</option>
                    {teamMembers.map((m) => (
                      <option key={m.id} value={m.name}>
                        {m.name} ({m.role})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">
                    Data Limite / Prazo (SLA)
                  </label>
                  <input
                    type="date"
                    id="input-demand-duedate"
                    value={dueDate}
                    onChange={(e) => setDueDate(e.target.value)}
                    className="w-full min-h-[44px] px-3.5 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-blue-500 focus:outline-none"
                  />
                </div>
              </div>

              {/* Rodapé de botões */}
              <div className="pt-4 border-t border-slate-200 flex items-center justify-end gap-2.5">
                <button
                  type="button"
                  id="btn-cancel-demand-modal"
                  onClick={onClose}
                  className="min-h-[44px] px-4 rounded-xl border border-slate-300 text-slate-700 font-semibold text-xs hover:bg-slate-50 active:bg-slate-100 transition-colors active:scale-95 touch-manipulation"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  id="btn-save-demand-modal"
                  className="min-h-[44px] px-5 rounded-xl bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white font-bold text-xs flex items-center gap-2 shadow-md shadow-blue-600/20 active:scale-95 touch-manipulation"
                >
                  <Save className="w-4 h-4" />
                  <span>{isEditing ? 'Salvar Alterações' : 'Criar Chamado'}</span>
                </button>
              </div>
            </form>
          ) : (
            /* Aba de Comentários & Histórico */
            <div className="space-y-4">
              <div className="space-y-3 max-h-[360px] overflow-y-auto pr-1">
                {demand?.comments && demand.comments.length > 0 ? (
                  demand.comments.map((c) => (
                    <div key={c.id} className="p-3 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
                      <div className="flex items-center justify-between text-xs">
                        <span className="font-bold text-slate-800">{c.authorName} ({c.authorRole})</span>
                        <span className="text-[10px] text-slate-400">
                          {new Date(c.createdAt).toLocaleString('pt-BR')}
                        </span>
                      </div>
                      <p className="text-xs text-slate-600 leading-relaxed">{c.content}</p>
                    </div>
                  ))
                ) : (
                  <p className="text-xs text-slate-400 text-center py-6">
                    Nenhum comentário registrado ainda.
                  </p>
                )}
              </div>

              {/* Formulário de Novo Comentário */}
              <form onSubmit={handleSendComment} className="pt-2 border-t border-slate-100 flex gap-2">
                <input
                  type="text"
                  id="input-new-comment"
                  value={commentText}
                  onChange={(e) => setCommentText(e.target.value)}
                  placeholder="Escreva uma observação técnica ou atualização..."
                  className="flex-1 min-h-[44px] px-3.5 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-blue-500 focus:outline-none"
                />
                <button
                  type="submit"
                  id="btn-send-comment"
                  disabled={!commentText.trim()}
                  className="min-h-[44px] px-4 rounded-xl bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white font-bold text-xs flex items-center gap-1.5 disabled:opacity-50 active:scale-95 touch-manipulation"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Enviar</span>
                </button>
              </form>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
