import React, { useState } from 'react';
import { 
  LogIn, 
  X, 
  ShieldCheck, 
  Lock, 
  Mail, 
  AlertCircle,
  Sparkles,
  Users
} from 'lucide-react';
import { User } from '../types';
import { AlkoLogo } from './AlkoLogo';

interface LoginModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLogin: (email: string, pass: string) => boolean;
  availableUsers: User[];
}

export const LoginModal: React.FC<LoginModalProps> = ({
  isOpen,
  onClose,
  onLogin,
  availableUsers,
}) => {
  const [email, setEmail] = useState('admin@alko.com.br');
  const [password, setPassword] = useState('Alko@2026');
  const [errorMsg, setErrorMsg] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    const ok = onLogin(email.trim(), password.trim());
    if (ok) {
      onClose();
    } else {
      setErrorMsg('Credenciais inválidas. Verifique o e-mail e senha informados.');
    }
  };

  const handleFillQuickAdmin = () => {
    setEmail('admin@alko.com.br');
    setPassword('Alko@2026');
    const ok = onLogin('admin@alko.com.br', 'Alko@2026');
    if (ok) onClose();
  };

  const handleSelectDemoUser = (user: User) => {
    setEmail(user.email);
    const pass = user.email === 'admin@alko.com.br' ? 'Alko@2026' : 'Alko@123';
    setPassword(pass);
    const ok = onLogin(user.email, pass);
    if (ok) onClose();
  };

  return (
    <div
      id="login-modal-overlay"
      className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 overflow-y-auto"
      onClick={onClose}
    >
      <div
        id="login-modal-card"
        onClick={(e) => e.stopPropagation()}
        className="bg-white w-full max-w-md rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-auto animate-in fade-in zoom-in-95 duration-150"
      >
        {/* Topo com Logo Alko com Fundo Transparente e Proporção Equilibrada */}
        <div className="p-5 border-b border-slate-100 flex items-center justify-between bg-slate-50/70">
          <div className="flex items-center gap-3">
            <AlkoLogo size="md" className="h-8 w-auto opacity-95" />
            <div className="pl-3 border-l border-slate-200">
              <h3 className="font-bold text-slate-900 text-xs sm:text-sm leading-tight">
                Portal de TI
              </h3>
              <p className="text-[10px] text-slate-500 font-medium leading-tight mt-0.5">
                Autenticação Corporativa
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-9 h-9 flex items-center justify-center rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-200 active:scale-95 touch-manipulation"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Formulário */}
        <div className="p-5 sm:p-6 space-y-4">
          {/* Botão de Preenchimento Rápido com 1 Toque */}
          <div className="p-3 bg-blue-50/90 border border-blue-200/80 rounded-xl space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-blue-900 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-blue-600" />
                Credencial Inicial de Administrador:
              </span>
            </div>
            <div className="text-[11px] text-blue-800 space-y-0.5">
              <div>Email: <strong>admin@alko.com.br</strong></div>
              <div>Senha: <strong>Alko@2026</strong></div>
            </div>
            <button
              type="button"
              id="btn-quick-fill-admin"
              onClick={handleFillQuickAdmin}
              className="w-full min-h-[40px] px-3 rounded-lg bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white font-bold text-xs shadow-sm active:scale-95 touch-manipulation transition-all"
            >
              Entrar como Administrador com 1 Toque
            </button>
          </div>

          {errorMsg && (
            <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-3.5">
            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">
                E-mail Corporativo
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                  type="email"
                  required
                  id="input-login-email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="admin@alko.com.br"
                  className="w-full min-h-[44px] pl-9 pr-3 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-blue-500 focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">
                Senha
              </label>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                  type="password"
                  required
                  id="input-login-password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full min-h-[44px] pl-9 pr-3 rounded-xl border border-slate-300 text-xs font-mono focus:ring-2 focus:ring-blue-500 focus:outline-none"
                />
              </div>
            </div>

            <button
              type="submit"
              id="btn-submit-login"
              className="w-full min-h-[44px] rounded-xl bg-slate-900 hover:bg-slate-800 active:bg-black text-white font-bold text-xs flex items-center justify-center gap-2 shadow-md transition-all active:scale-95 touch-manipulation"
            >
              <LogIn className="w-4 h-4" />
              <span>Autenticar no Sistema</span>
            </button>
          </form>

          {/* Trocar para outro perfil rápido */}
          <div className="pt-3 border-t border-slate-100">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-2">
              Ou selecione um colaborador da Alko:
            </span>
            <div className="grid grid-cols-2 gap-1.5 max-h-36 overflow-y-auto pr-1">
              {availableUsers.map((u) => (
                <button
                  key={u.id}
                  type="button"
                  id={`btn-login-as-${u.id}`}
                  onClick={() => handleSelectDemoUser(u)}
                  className="p-2 rounded-lg border border-slate-200 text-left hover:border-blue-300 hover:bg-blue-50/40 text-xs transition-colors active:scale-95 touch-manipulation truncate"
                >
                  <span className="font-bold text-slate-800 block truncate">{u.name}</span>
                  <span className="text-[10px] text-slate-500 block truncate">{u.role}</span>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
