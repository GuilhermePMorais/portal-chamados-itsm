import React, { useState } from 'react';
import { 
  Users, 
  UserPlus, 
  ShieldCheck, 
  ShieldAlert, 
  Mail, 
  Building, 
  Trash2, 
  Edit3, 
  Lock,
  CheckCircle2,
  XCircle,
  X
} from 'lucide-react';
import { User, UserRole } from '../types';

interface TeamManagementProps {
  users: User[];
  currentUser: User | null;
  onSaveUser: (userData: Omit<User, 'id' | 'createdAt'> & { id?: string; password?: string }) => void;
  onDeleteUser: (userId: string) => void;
  onSwitchToAdmin: () => void;
}

const ROLES: UserRole[] = [
  'Administrador',
  'Supervisor de Facilities',
  'Analista',
  'Assistente',
  'Técnico',
  'Auxiliar',
];

export const TeamManagement: React.FC<TeamManagementProps> = ({
  users,
  currentUser,
  onSaveUser,
  onDeleteUser,
  onSwitchToAdmin,
}) => {
  const isAdmin = currentUser?.role === 'Administrador';

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<User | null>(null);

  // Form states
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [role, setRole] = useState<UserRole>('Técnico');
  const [department, setDepartment] = useState('Suporte Técnico');
  const [password, setPassword] = useState('');
  const [active, setActive] = useState(true);

  const handleOpenCreate = () => {
    setName('');
    setEmail('');
    setRole('Técnico');
    setDepartment('Suporte Técnico');
    setPassword('Alko@123');
    setActive(true);
    setEditingUser(null);
    setIsModalOpen(true);
  };

  const handleOpenEdit = (user: User) => {
    setName(user.name);
    setEmail(user.email);
    setRole(user.role);
    setDepartment(user.department);
    setPassword('');
    setActive(user.active);
    setEditingUser(user);
    setIsModalOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !email.trim()) return;

    onSaveUser({
      id: editingUser?.id,
      name: name.trim(),
      email: email.trim().toLowerCase(),
      role,
      department,
      active,
      password: password ? password.trim() : undefined,
    });

    setIsModalOpen(false);
    setEditingUser(null);
  };

  if (!isAdmin) {
    return (
      <div className="bg-white rounded-2xl border border-slate-200 p-8 sm:p-12 text-center max-w-lg mx-auto shadow-sm my-8">
        <ShieldAlert className="w-12 h-12 text-amber-500 mx-auto mb-3" />
        <h2 className="text-xl font-bold text-slate-900">Acesso Restrito ao Administrador</h2>
        <p className="text-xs sm:text-sm text-slate-500 mt-2 leading-relaxed">
          Você está conectado como <strong>{currentUser?.name}</strong> com o papel de <strong>{currentUser?.role}</strong>.
          Apenas administradores podem gerenciar e cadastrar a equipe de TI da Alko do Brasil.
        </p>
        <button
          onClick={onSwitchToAdmin}
          className="mt-5 min-h-[44px] px-5 rounded-xl bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white font-bold text-xs shadow-md active:scale-95 touch-manipulation"
        >
          Conectar como Administrador (admin@alko.com.br)
        </button>
      </div>
    );
  }

  return (
    <div id="team-management-view" className="space-y-4 pb-12">
      {/* Topo com Botão Adicionar Membro */}
      <div className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-base sm:text-lg font-bold text-slate-900 flex items-center gap-2">
            <Users className="w-5 h-5 text-blue-600" />
            Controle de Equipe e Níveis de Acesso
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Gerenciamento de credenciais e permissões operacionais do setor de TI da Alko
          </p>
        </div>

        <button
          id="btn-add-team-member"
          onClick={handleOpenCreate}
          className="min-h-[44px] px-4 rounded-xl bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-sm active:scale-95 touch-manipulation shrink-0"
        >
          <UserPlus className="w-4 h-4" />
          <span>Cadastrar Colaborador</span>
        </button>
      </div>

      {/* Grid de Membros */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {users.map((user) => (
          <div
            key={user.id}
            id={`user-card-${user.id}`}
            className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm hover:shadow-md transition-all flex flex-col justify-between space-y-4"
          >
            <div className="space-y-3">
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-3">
                  {user.avatarUrl ? (
                    <img
                      src={user.avatarUrl}
                      alt={user.name}
                      className="w-12 h-12 rounded-xl object-cover ring-2 ring-blue-500/20"
                    />
                  ) : (
                    <div className="w-12 h-12 rounded-xl bg-blue-100 text-blue-800 font-black flex items-center justify-center text-base">
                      {user.name.charAt(0)}
                    </div>
                  )}

                  <div>
                    <h3 className="text-sm font-bold text-slate-900 leading-snug">
                      {user.name}
                    </h3>
                    <span className="text-xs text-slate-500 block truncate">
                      {user.email}
                    </span>
                  </div>
                </div>

                <span
                  className={`text-[10px] font-extrabold px-2 py-0.5 rounded uppercase tracking-wider ${
                    user.role === 'Administrador'
                      ? 'bg-blue-100 text-blue-800'
                      : user.role === 'Supervisor de Facilities'
                      ? 'bg-indigo-100 text-indigo-800'
                      : user.role === 'Analista'
                      ? 'bg-purple-100 text-purple-800'
                      : 'bg-slate-100 text-slate-700'
                  }`}
                >
                  {user.role}
                </span>
              </div>

              <div className="pt-2 border-t border-slate-100 space-y-1.5 text-xs text-slate-600">
                <div className="flex items-center gap-1.5">
                  <Building className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                  <span className="truncate">{user.department}</span>
                </div>
                <div className="flex items-center gap-1.5">
                  {user.active ? (
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                  ) : (
                    <XCircle className="w-3.5 h-3.5 text-rose-500 shrink-0" />
                  )}
                  <span className={user.active ? 'text-emerald-700 font-semibold' : 'text-rose-700 font-semibold'}>
                    {user.active ? 'Acesso Ativo' : 'Acesso Bloqueado'}
                  </span>
                </div>
              </div>
            </div>

            {/* Ações do Usuário */}
            <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
              <button
                id={`btn-edit-user-${user.id}`}
                onClick={() => handleOpenEdit(user)}
                className="min-h-[40px] px-3 rounded-lg text-blue-700 hover:bg-blue-50 font-semibold text-xs flex items-center gap-1.5 transition-colors active:scale-95 touch-manipulation"
              >
                <Edit3 className="w-3.5 h-3.5" />
                <span>Editar Papel</span>
              </button>

              {user.email !== 'admin@alko.com.br' && (
                <button
                  id={`btn-delete-user-${user.id}`}
                  onClick={() => {
                    if (window.confirm(`Excluir o usuário ${user.name}?`)) {
                      onDeleteUser(user.id);
                    }
                  }}
                  className="min-h-[40px] px-2.5 rounded-lg text-rose-500 hover:bg-rose-50 hover:text-rose-700 font-semibold text-xs flex items-center gap-1 transition-colors active:scale-95 touch-manipulation"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Modal de Cadastrar/Editar Usuário */}
      {isModalOpen && (
        <div
          id="user-modal-overlay"
          className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto"
          onClick={() => setIsModalOpen(false)}
        >
          <div
            id="user-modal-card"
            onClick={(e) => e.stopPropagation()}
            className="bg-white w-full max-w-md rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-auto animate-in fade-in zoom-in-95 duration-150"
          >
            <div className="p-4 sm:p-5 border-b border-slate-200 flex items-center justify-between bg-slate-50">
              <h3 className="font-bold text-slate-900 text-sm sm:text-base">
                {editingUser ? 'Editar Usuário da Equipe' : 'Cadastrar Novo Usuário'}
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="w-8 h-8 rounded-lg flex items-center justify-center text-slate-400 hover:text-slate-700 hover:bg-slate-200"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-5 space-y-3.5">
              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  Nome Completo *
                </label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Ex: Marcos Vinicius"
                  className="w-full min-h-[44px] px-3.5 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-blue-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  E-mail Corporativo (@alko.com.br) *
                </label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="usuario@alko.com.br"
                  className="w-full min-h-[44px] px-3.5 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-blue-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  Papel no Sistema *
                </label>
                <select
                  value={role}
                  onChange={(e) => setRole(e.target.value as UserRole)}
                  className="w-full min-h-[44px] px-3.5 rounded-xl border border-slate-300 text-xs font-semibold text-slate-800 bg-white focus:ring-2 focus:ring-blue-500"
                >
                  {ROLES.map((r) => (
                    <option key={r} value={r}>
                      {r}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  Departamento
                </label>
                <input
                  type="text"
                  value={department}
                  onChange={(e) => setDepartment(e.target.value)}
                  placeholder="Ex: Suporte Nível 1"
                  className="w-full min-h-[44px] px-3.5 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-blue-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  {editingUser ? 'Nova Senha (deixe em branco para manter)' : 'Senha de Acesso *'}
                </label>
                <input
                  type="text"
                  required={!editingUser}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Ex: Alko@123"
                  className="w-full min-h-[44px] px-3.5 rounded-xl border border-slate-300 text-xs font-mono focus:ring-2 focus:ring-blue-500 focus:outline-none"
                />
              </div>

              <div className="pt-2 flex items-center gap-2">
                <input
                  type="checkbox"
                  id="checkbox-user-active"
                  checked={active}
                  onChange={(e) => setActive(e.target.checked)}
                  className="w-4 h-4 rounded text-blue-600"
                />
                <label htmlFor="checkbox-user-active" className="text-xs font-semibold text-slate-700 cursor-pointer">
                  Usuário Ativo com permissão de login
                </label>
              </div>

              <div className="pt-4 border-t border-slate-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="min-h-[42px] px-4 rounded-xl border border-slate-300 text-slate-600 font-semibold text-xs hover:bg-slate-50 active:scale-95 touch-manipulation"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="min-h-[42px] px-5 rounded-xl bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white font-bold text-xs shadow-sm active:scale-95 touch-manipulation"
                >
                  {editingUser ? 'Salvar Alterações' : 'Cadastrar'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
