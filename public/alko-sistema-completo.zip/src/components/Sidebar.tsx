import React from 'react';
import { 
  LayoutDashboard, 
  KanbanSquare, 
  ClipboardList, 
  StickyNote, 
  History, 
  Users, 
  X, 
  RotateCcw,
  Sparkles,
  Info,
  Download
} from 'lucide-react';
import { ActiveTab, User } from '../types';
import { AlkoLogo } from './AlkoLogo';

interface SidebarProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  currentUser: User | null;
  isOpenMobile: boolean;
  onCloseMobile: () => void;
  demandsCount: number;
  notesCount: number;
  onResetData: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  setActiveTab,
  currentUser,
  isOpenMobile,
  onCloseMobile,
  demandsCount,
  notesCount,
  onResetData,
}) => {
  const isAdmin = currentUser?.role === 'Administrador';

  const navItems = [
    {
      id: 'dashboard' as ActiveTab,
      label: 'Visão Geral',
      icon: LayoutDashboard,
      description: 'Métricas e gráficos do setor',
    },
    {
      id: 'kanban' as ActiveTab,
      label: 'Quadro Kanban',
      icon: KanbanSquare,
      badge: demandsCount,
      description: 'Fluxo visual de atividades',
    },
    {
      id: 'demands' as ActiveTab,
      label: 'Demandas',
      icon: ClipboardList,
      badge: demandsCount,
      description: 'Lista completa e filtros',
    },
    {
      id: 'notes' as ActiveTab,
      label: 'Notas Rápidas',
      icon: StickyNote,
      badge: notesCount,
      description: 'Post-its e lembretes adesivos',
    },
    {
      id: 'audit' as ActiveTab,
      label: 'Auditoria',
      icon: History,
      description: 'Logs e exportação CSV',
    },
    {
      id: 'team' as ActiveTab,
      label: 'Equipe e Acessos',
      icon: Users,
      requiresAdmin: true,
      description: 'Papéis e permissões',
    },
  ];

  const handleSelectTab = (tab: ActiveTab) => {
    setActiveTab(tab);
    onCloseMobile();
  };

  return (
    <>
      {/* Backdrop para mobile */}
      {isOpenMobile && (
        <div
          id="sidebar-backdrop"
          onClick={onCloseMobile}
          className="fixed inset-0 z-40 bg-slate-900/60 backdrop-blur-sm lg:hidden transition-opacity"
        />
      )}

      {/* Container da Sidebar */}
      <aside
        id="app-sidebar"
        className={`fixed top-0 bottom-0 left-0 z-50 w-72 bg-white border-r border-slate-200 flex flex-col justify-between transition-transform duration-300 ease-in-out lg:translate-x-0 lg:static lg:z-10 ${
          isOpenMobile ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {/* Topo do menu */}
        <div className="flex flex-col h-full overflow-y-auto">
          {/* Cabeçalho do Drawer Mobile com Logo Alko */}
          <div className="flex items-center justify-between p-4 border-b border-slate-100 lg:hidden">
            <AlkoLogo size="sm" className="h-7 w-auto opacity-95" />
            <button
              id="btn-close-sidebar-mobile"
              onClick={onCloseMobile}
              aria-label="Fechar menu"
              className="w-10 h-10 flex items-center justify-center rounded-xl text-slate-500 hover:bg-slate-100 active:bg-slate-200 active:scale-95 touch-manipulation"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Lista de Navegação */}
          <div className="p-3 space-y-1">
            <div className="px-3 py-2 text-[11px] font-bold uppercase tracking-wider text-slate-400">
              Navegação Principal
            </div>

            {navItems.map((item) => {
              const isActive = activeTab === item.id;
              const Icon = item.icon;

              return (
                <button
                  key={item.id}
                  id={`nav-item-${item.id}`}
                  onClick={() => handleSelectTab(item.id)}
                  className={`w-full flex items-center justify-between min-h-[48px] px-3.5 py-2.5 rounded-xl text-left transition-all duration-150 touch-manipulation group active:scale-[0.98] ${
                    isActive
                      ? 'bg-blue-600 text-white font-semibold shadow-md shadow-blue-600/20'
                      : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900 active:bg-slate-200'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <Icon
                      className={`w-5 h-5 shrink-0 transition-colors ${
                        isActive ? 'text-white' : 'text-slate-400 group-hover:text-blue-600'
                      }`}
                    />
                    <div>
                      <span className="text-sm block leading-tight">{item.label}</span>
                      <span
                        className={`text-[11px] block leading-tight mt-0.5 ${
                          isActive ? 'text-blue-100' : 'text-slate-400'
                        }`}
                      >
                        {item.description}
                      </span>
                    </div>
                  </div>

                  {item.badge !== undefined && (
                    <span
                      className={`text-xs font-bold px-2 py-0.5 rounded-full ${
                        isActive
                          ? 'bg-white/20 text-white'
                          : 'bg-slate-100 text-slate-600 border border-slate-200'
                      }`}
                    >
                      {item.badge}
                    </span>
                  )}

                  {item.requiresAdmin && (
                    <span
                      className={`text-[10px] font-bold uppercase px-1.5 py-0.5 rounded ${
                        isActive
                          ? 'bg-white/20 text-white'
                          : 'bg-amber-100 text-amber-800'
                      }`}
                    >
                      Admin
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          {/* Dica de Toque & Responsividade */}
          <div className="m-3 p-3.5 bg-blue-50/80 border border-blue-100 rounded-xl">
            <div className="flex items-start gap-2">
              <Sparkles className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
              <div className="text-xs text-blue-900 leading-relaxed">
                <span className="font-semibold block mb-0.5">Suporte a Toque Ativo</span>
                No celular, toque nos botões do Kanban para avançar e voltar cards com 1 toque direto!
              </div>
            </div>
          </div>
        </div>

        {/* Rodapé da Sidebar */}
        <div className="p-3 border-t border-slate-200 bg-slate-50/50 space-y-2">
          {/* Informações do Usuário Conectado */}
          {currentUser && (
            <div className="px-2 py-1 flex items-center justify-between text-xs text-slate-500">
              <div className="truncate">
                <span className="font-medium text-slate-700 block truncate">{currentUser.name}</span>
                <span className="text-[11px] text-slate-500 block truncate">{currentUser.email}</span>
              </div>
              <span className="text-[10px] font-bold px-2 py-0.5 bg-slate-200 text-slate-700 rounded-md shrink-0">
                {currentUser.role.split(' ')[0]}
              </span>
            </div>
          )}

          {/* Botão de Download do ZIP no Rodapé */}
          <a
            id="btn-sidebar-download-zip"
            href="/alko-sistema-completo.zip"
            download="alko-sistema-completo.zip"
            className="w-full flex items-center justify-center gap-2 min-h-[40px] px-3 py-2 text-xs font-semibold text-blue-700 bg-blue-50 hover:bg-blue-100 active:bg-blue-200 border border-blue-200/80 rounded-lg transition-colors touch-manipulation active:scale-98"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Baixar Projeto (.ZIP)</span>
          </a>

          {/* Botão de Restaurar Dados Iniciais */}
          <button
            id="btn-sidebar-reset-data"
            onClick={() => {
              if (window.confirm('Deseja restaurar as demandas e notas de exemplo da Alko?')) {
                onResetData();
              }
            }}
            className="w-full flex items-center justify-center gap-2 min-h-[40px] px-3 py-2 text-xs font-medium text-slate-500 hover:text-slate-800 hover:bg-slate-200/60 active:bg-slate-200 rounded-lg transition-colors touch-manipulation active:scale-98"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Restaurar Dados da Alko</span>
          </button>
        </div>
      </aside>
    </>
  );
};
