import React from 'react';
import { 
  Menu, 
  Plus, 
  User as UserIcon, 
  LogOut, 
  LogIn, 
  ShieldCheck, 
  Wifi,
  Download
} from 'lucide-react';
import { User } from '../types';
import { AlkoLogo } from './AlkoLogo';

interface HeaderProps {
  currentUser: User | null;
  onOpenMobileMenu: () => void;
  onOpenNewDemandModal: () => void;
  onOpenLoginModal: () => void;
  onLogout: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentUser,
  onOpenMobileMenu,
  onOpenNewDemandModal,
  onOpenLoginModal,
  onLogout,
}) => {
  return (
    <header 
      id="main-header"
      className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-slate-200 px-4 lg:px-6 py-3 transition-colors"
    >
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-3">
        {/* Lado Esquerdo: Botão Mobile + Logo Alko */}
        <div className="flex items-center gap-3">
          <button
            id="btn-mobile-menu-toggle"
            onClick={onOpenMobileMenu}
            aria-label="Abrir menu lateral de navegação"
            className="lg:hidden flex items-center justify-center w-11 h-11 rounded-xl text-slate-700 bg-slate-100 hover:bg-slate-200 active:bg-slate-300 transition-transform active:scale-95 touch-manipulation focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <Menu className="w-6 h-6" />
          </button>

          <div className="flex items-center gap-3">
            <AlkoLogo size="sm" className="h-8 max-w-[135px] sm:max-w-none opacity-95" />
            <div className="hidden md:block pl-3 border-l border-slate-200">
              <div className="flex items-center gap-2">
                <span className="font-bold text-slate-800 text-xs tracking-tight leading-none">
                  Portal de TI
                </span>
                <span className="inline-flex items-center gap-1 text-[10px] font-semibold uppercase tracking-wider px-1.5 py-0.5 rounded-full bg-blue-50 text-blue-700 border border-blue-200">
                  <Wifi className="w-2.5 h-2.5 text-emerald-500" />
                  Operacional
                </span>
              </div>
              <p className="text-[10px] text-slate-500 font-medium leading-none mt-1">
                Gestão de Demandas &amp; Facilities
              </p>
            </div>
          </div>
        </div>

        {/* Lado Direito: Ações Rápidas & Usuário */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Botão Baixar Projeto ZIP */}
          <a
            id="btn-header-download-zip"
            href="/alko-sistema-completo.zip"
            download="alko-sistema-completo.zip"
            title="Baixar código-fonte completo (.ZIP) para seu PC"
            className="flex items-center justify-center gap-1.5 h-11 px-3 sm:px-3.5 rounded-xl bg-slate-100 hover:bg-slate-200 active:bg-slate-300 text-slate-700 font-medium text-xs sm:text-sm border border-slate-200 transition-all duration-150 active:scale-95 touch-manipulation focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <Download className="w-4 h-4 text-blue-600" />
            <span className="hidden md:inline">Baixar (.ZIP)</span>
            <span className="md:hidden">ZIP</span>
          </a>

          {/* Botão Nova Demanda (Destacado e de toque fácil) */}
          <button
            id="btn-header-new-demand"
            onClick={onOpenNewDemandModal}
            className="flex items-center justify-center gap-2 h-11 px-3.5 sm:px-4 rounded-xl bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white font-semibold text-sm shadow-md shadow-blue-600/25 transition-all duration-150 active:scale-95 touch-manipulation focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
          >
            <Plus className="w-5 h-5" />
            <span className="hidden sm:inline">Nova Demanda</span>
            <span className="sm:hidden">Novo</span>
          </button>

          {/* Perfil do Usuário / Login */}
          {currentUser ? (
            <div className="flex items-center gap-2 pl-2 border-l border-slate-200">
              <div className="flex items-center gap-2.5">
                {currentUser.avatarUrl ? (
                  <img
                    src={currentUser.avatarUrl}
                    alt={currentUser.name}
                    className="w-10 h-10 rounded-xl object-cover ring-2 ring-blue-500/30"
                  />
                ) : (
                  <div className="w-10 h-10 rounded-xl bg-slate-200 flex items-center justify-center text-slate-700 font-semibold text-sm">
                    {currentUser.name.charAt(0)}
                  </div>
                )}
                <div className="hidden md:block text-left">
                  <div className="flex items-center gap-1.5">
                    <span className="text-sm font-bold text-slate-800 leading-tight">
                      {currentUser.name}
                    </span>
                    {currentUser.role === 'Administrador' && (
                      <ShieldCheck className="w-4 h-4 text-blue-600" title="Administrador" />
                    )}
                  </div>
                  <span className="text-[11px] font-medium text-slate-500 block leading-tight">
                    {currentUser.role}
                  </span>
                </div>
              </div>

              {/* Botão de Trocar/Sair */}
              <button
                id="btn-header-logout"
                onClick={onLogout}
                title="Desconectar ou trocar de usuário"
                aria-label="Desconectar do sistema"
                className="flex items-center justify-center w-11 h-11 rounded-xl text-slate-500 hover:text-rose-600 hover:bg-rose-50 active:bg-rose-100 transition-transform active:scale-95 touch-manipulation focus:outline-none focus:ring-2 focus:ring-rose-500"
              >
                <LogOut className="w-5 h-5" />
              </button>
            </div>
          ) : (
            <button
              id="btn-header-login"
              onClick={onOpenLoginModal}
              className="flex items-center gap-2 h-11 px-4 rounded-xl border border-slate-300 text-slate-700 hover:bg-slate-100 active:bg-slate-200 font-semibold text-sm transition-transform active:scale-95 touch-manipulation"
            >
              <LogIn className="w-4 h-4 text-blue-600" />
              <span>Entrar</span>
            </button>
          )}
        </div>
      </div>
    </header>
  );
};
