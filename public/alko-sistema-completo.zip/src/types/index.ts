export type UserRole = 
  | 'Administrador'
  | 'Supervisor de Facilities'
  | 'Analista'
  | 'Assistente'
  | 'Técnico'
  | 'Auxiliar';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  department: string;
  avatarUrl?: string;
  active: boolean;
  createdAt: string;
}

export type DemandStatus = 
  | 'A Fazer'
  | 'Em Andamento'
  | 'Aguardando Fornecedor'
  | 'Em Testes'
  | 'Concluído';

export type DemandPriority = 'Baixa' | 'Média' | 'Alta' | 'Crítica';

export type DemandCategory = 
  | 'Hardware'
  | 'Software'
  | 'Redes & Internet'
  | 'Acessos & Contas'
  | 'Impressoras'
  | 'Telefonia'
  | 'ERP / SAP'
  | 'Facilities & Infra';

export interface DemandComment {
  id: string;
  authorName: string;
  authorRole: string;
  content: string;
  createdAt: string;
}

export interface Demand {
  id: string;
  code: string; // Ex: ALK-101
  title: string;
  description: string;
  requester: string;
  requesterEmail: string;
  department: string;
  category: DemandCategory;
  priority: DemandPriority;
  status: DemandStatus;
  assignedTo?: string; // Nome do técnico responsável
  dueDate: string;
  createdAt: string;
  updatedAt: string;
  resolutionTimeHours?: number;
  comments: DemandComment[];
  tags: string[];
}

export interface QuickNote {
  id: string;
  title: string;
  content: string;
  color: 'yellow' | 'green' | 'blue' | 'purple' | 'rose';
  pinned: boolean;
  authorId: string;
  authorName: string;
  createdAt: string;
  updatedAt: string;
}

export interface AuditLogItem {
  id: string;
  action: 'Criação' | 'Atualização' | 'Exclusão' | 'Login' | 'Status Alterado' | 'Permissão';
  description: string;
  userEmail: string;
  userName: string;
  entityType: 'Demanda' | 'Nota' | 'Usuário' | 'Autenticação';
  entityId?: string;
  timestamp: string;
}

export type ActiveTab = 'dashboard' | 'kanban' | 'demands' | 'notes' | 'audit' | 'team';
