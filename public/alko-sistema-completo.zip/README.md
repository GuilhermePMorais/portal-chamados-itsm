# Alko do Brasil — Sistema de Gestão de Demandas de TI & Facilities

Sistema web corporativo desenvolvido especificamente para o setor de Tecnologia da Informação e Facilities da **Alko do Brasil**. Desenvolvido com React, TypeScript, Tailwind CSS, Vite e arquitetura responsiva voltada para desktop e dispositivos móveis (smartphones e tablets).

---

## 🚀 1. Como Baixar o Sistema Completo

Você pode baixar todo o código-fonte deste sistema de duas formas diretas:

### Opção A: Download Direto em arquivo `.ZIP`
1. No menu superior direito da interface do **Google AI Studio**, clique no ícone de engrenagem / menu de opções (**Settings** ou **Export**).
2. Selecione a opção **"Download ZIP"** (ou **"Export to ZIP"**).
3. Salve o arquivo no seu computador e descompacte a pasta onde preferir (ex: `C:\Projetos\alko-ti`).

### Opção B: Exportar para o GitHub
1. No mesmo menu de opções, clique em **"Push to GitHub"** ou **"Export to GitHub"**.
2. Conecte sua conta do GitHub para criar o repositório automaticamente.

---

## 💻 2. Como Rodar Localmente no seu Computador

### Pré-requisitos
- Ter o **Node.js** instalado (versão 18 ou superior recomendada): Baixe gratuitamente em [nodejs.org](https://nodejs.org/).
- Qualquer editor de código (como VS Code) ou apenas o Terminal / Prompt de Comando.

### Passo a Passo:
1. Abra o Terminal ou Prompt de Comando (CMD / PowerShell).
2. Navegue até a pasta do projeto descompactado:
   ```bash
   cd caminho/para/a/pasta/do/projeto
   ```
3. Instale as dependências:
   ```bash
   npm install
   ```
4. Inicie o servidor de desenvolvimento:
   ```bash
   npm run dev
   ```
5. Abra o navegador em:
   ```
   http://localhost:3000
   ```

---

## 🌐 3. Como Rodar em Rede Local (Wi-Fi / LAN da Empresa)

Para que qualquer colega de trabalho, computador, tablet ou celular conectado à mesma rede da empresa acesse o sistema:

### Passo 1: Executar o comando com liberação de Host
Execute o comando de inicialização com o parâmetro `--host 0.0.0.0`:
```bash
npm run dev -- --host 0.0.0.0
```

### Passo 2: Descobrir o IP do seu computador na rede
- **No Windows:**
  1. Pressione `Win + R`, digite `cmd` e aperte Enter.
  2. Digite o comando:
     ```cmd
     ipconfig
     ```
  3. Procure pela linha **Endereço IPv4** (exemplo: `192.168.1.45` ou `10.0.0.12`).

- **No Linux ou Mac:**
  1. Abra o terminal e digite:
     ```bash
     ip a
     # ou
     ifconfig
     ```

### Passo 3: Acessar de outros dispositivos
Em qualquer celular, tablet ou outro computador conectado à mesma rede Wi-Fi/cabo, abra o navegador e acesse:
```
http://SEU_IP_AQUI:3000
```
*Exemplo:* `http://192.168.1.45:3000`

> 💡 **Dica de Firewall (Windows):** Se outros aparelhos não conseguirem conectar, abra o "Firewall do Windows com Segurança Avançada", vá em "Regras de Entrada" -> "Nova Regra" -> Selecione "Porta" -> TCP -> `3000` -> "Permitir a conexão".

---

## ☁️ 4. Como Subir o Sistema Online com Ferramentas 100% Gratuitas

Você pode colocar o sistema no ar de forma profissional, com HTTPS seguro, domínio próprio ou gratuito, sem pagar nada:

### Método 1: Vercel (Recomendado - Mais Rápido e Gratuito)
1. Crie uma conta gratuita em [vercel.com](https://vercel.com).
2. Instale o utilitário da Vercel no seu computador pelo terminal:
   ```bash
   npm i -g vercel
   ```
3. Na pasta do projeto, digite:
   ```bash
   vercel
   ```
4. Siga as instruções no terminal (basta pressionar Enter nas opções padrão). Em menos de 1 minuto seu link seguro estará no ar (ex: `https://alko-ti.vercel.app`).

*Alternativa via GitHub:*
- Suba o código para o seu GitHub.
- Entre na Vercel, clique em **"Add New Project"**, selecione o repositório e clique em **Deploy**.

---

### Método 2: Netlify (Sem precisar de terminal - Arrastar e Soltar)
1. No seu computador, gere os arquivos finais de produção com:
   ```bash
   npm run build
   ```
   *Isso criará uma pasta chamada `dist` com todo o sistema compilado.*
2. Acesse [app.netlify.com/drop](https://app.netlify.com/drop).
3. Arraste e solte a pasta **`dist`** dentro da tela do navegador.
4. Pronto! O Netlify publicará seu site em segundos com link HTTPS gratuito.

---

### Método 3: Render (Plano Gratuito)
1. Crie uma conta gratuita em [render.com](https://render.com).
2. Clique em **"New +"** -> **"Static Site"**.
3. Conecte seu repositório do GitHub.
4. Preencha:
   - **Build Command:** `npm run build`
   - **Publish Directory:** `dist`
5. Clique em **"Create Static Site"**.

---

## 🔑 5. Credenciais Padrão de Acesso

O sistema vem pré-configurado com as credenciais administrativas corporativas:

| Tipo | E-mail | Senha | Nível de Permissão |
| :--- | :--- | :--- | :--- |
| **Administrador** | `admin@alko.com.br` | `Alko@2026` | Acesso total (Equipe, Demandas, Auditoria) |
| **Supervisor Facilities** | `carlos.facilities@alko.com.br` | `Alko@123` | Supervisão operacional e relatórios |
| **Analista de Sistemas** | `fernanda.sistemas@alko.com.br` | `Alko@123` | Gestão de demandas e chamados |
| **Técnico de Suporte** | `marcos.ti@alko.com.br` | `Alko@123` | Atendimento operacional e notas |

> ⚡ **Acesso Rápido:** No modal de login há um botão com 1 toque para entrar como Administrador diretamente ou selecionar qualquer um dos colaboradores da equipe.

---

## 📦 6. Recursos e Funcionalidades Incluídas

- **Identidade Visual Alko do Brasil:** Logotipo oficial vetorizado em alta definição com fundo transparente, integrado sutilmente no topo e tela de autenticação.
- **Plano de Fundo Farmacêutico:** Textura sutil de ambiente laboratorial e biotecnológico com acabamento fosco suave garantindo total contraste e legibilidade.
- **Painel Geral (Dashboard):** Indicadores de SLAs, chamados em aberto, demandas críticas e gráficos de distribuição por categoria.
- **Quadro Kanban:** 5 fases de atendimento com botões táteis de avanço rápido e suporte a drag-and-drop.
- **Gestão Completa de Demandas:** Pesquisa por código/termo, filtros por prioridade e categoria, abertura e edição de chamados com histórico e comentários.
- **Lembretes Rápidos (Post-its):** Notas coloridas adesivas com fixação no topo e edição rápida.
- **Auditoria & Compliance:** Registro automático de todas as ações dos usuários com botão para **Exportar em formato CSV**.
- **Gestão de Equipe (Admin):** Controle de membros, cargos e redefinição de senhas.
- **Persistência de Dados:** Funcionamento offline-first via `LocalStorage` com conector integrado para banco em nuvem `Supabase` gratuito.
